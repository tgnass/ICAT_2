public class DataStructureException extends Exception {

    public DataStructureException(String string) {
        super(string);
    }
    
}
